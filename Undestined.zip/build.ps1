<#
Build script - usage with msvc initialized, run .\build.ps1 from root directory i.e. the folder where build.ps1 is present.
support for clang will be added
#>
if(!(Test-Path("./build/"))) {	New-Item -Itemtype Directory "build" }

$source_name = "..\code\*.cpp"
$executable_name = "Undestined.exe"

$lib_path = "..\libs\SDL2\SDL2-2.0.14\lib\x64"
$include_path = "..\code\headers\"
$extern_path =  "..\code\extern\"
$sdl_include = "..\libs\SDL2\SDL2-2.0.14"

$compiler_flags = "/nologo", "/EHsc", "/Zi", "/FC"
# $linker_flags =

$libraries = "SDL2.lib", "SDL2main.lib", "shell32.lib"

Push-Location .\build

#cl /MD $source_name /Fe$executable_name $compiler_flags /I$include_path /link /LIBPATH:$lib_path $libraries $linker_flags /SUBSYSTEM:console

cl $source_name /O2 /Fe$executable_name /I$sdl_include /I$include_path /I$extern_path  $compiler_flags /link /LIBPATH:$lib_path $libraries /subsystem:windows

#cl -DCONSOLE $source_name /Fe$executable_name /I$include_path1 /I$include_path2  $compiler_flags /link /LIBPATH:$lib_path $libraries $linker_flags /subsystem:console

Pop-Location